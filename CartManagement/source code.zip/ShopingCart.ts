

    var lprice2 =document.querySelector('p1');
console.log(lprice2);
